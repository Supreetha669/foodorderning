import styled from 'styled-components';

const AlignBottom = styled.div`
  display: flex;
  align-items: flex-end;
  width: 100%:
`;

export default AlignBottom;
