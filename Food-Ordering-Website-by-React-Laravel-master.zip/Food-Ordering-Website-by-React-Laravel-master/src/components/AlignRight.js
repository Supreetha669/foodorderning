import styled from 'styled-components';

const AlignRight = styled.div`
  justify-content: flex-end;
  display: flex;
`;

export default AlignRight;
