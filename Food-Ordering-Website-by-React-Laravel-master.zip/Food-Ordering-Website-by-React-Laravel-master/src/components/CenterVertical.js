import styled from 'styled-components';

const CenterVertical = styled.div`
  display: flex;
  align-items: center;
`;

export default CenterVertical;
