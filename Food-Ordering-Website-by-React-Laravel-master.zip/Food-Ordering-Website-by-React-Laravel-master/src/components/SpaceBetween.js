import CenterVertical from './CenterVertical';

const SpaceBetween = CenterVertical.extend`
  justify-content: space-between;
  width: 100%;
`;

export default SpaceBetween;
