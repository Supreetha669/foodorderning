const INPUT_WIDTH = '450px';
const ICON_WIDTH = 17;

export { INPUT_WIDTH, ICON_WIDTH };
